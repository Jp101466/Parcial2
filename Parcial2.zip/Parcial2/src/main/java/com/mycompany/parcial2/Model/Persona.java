/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.parcial2.Model;

import com.mycompany.parcial2.View.Empleado;

/**
 *
 * @author ASUS
 */
public abstract class Persona extends Empleado{
    
    protected String Txtnombre;

    public Persona(String Txtnombre) {
        this.Txtnombre = Txtnombre;
    }
    
    public abstract String datos();
}
